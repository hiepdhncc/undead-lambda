const AWS = require('aws-sdk');

AWS.config.update({
  region: 'ap-southeast-1',
});

module.exports = new AWS.DynamoDB.DocumentClient();
