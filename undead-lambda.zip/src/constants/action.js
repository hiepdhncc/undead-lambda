exports.createCharacterType = 'createCharacterType';
exports.findCharacterType = 'findCharacterType';
exports.findAllCharacterType = 'findAllCharacterType';
exports.deleteCharacterType = 'deleteCharacterType';
exports.modifyCharacterType = 'modifyCharacterType';
