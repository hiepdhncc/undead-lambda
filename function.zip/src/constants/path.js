// exports.healthPath = '/health';
// exports.productPath = '/product';
// exports.productsPath = '/products';
exports.characterTypePath = '/character-type';
exports.characterTypesPath = '/character-types';
exports.characterPath = '/character';
exports.charactersPath = '/characters';
exports.userCharacter = '/user-character';
exports.userCharacters = '/user-characters';

// module.exports = {healthPath,productPath,productsPath};