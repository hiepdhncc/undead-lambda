const characterType = "character-type"; 

module.exports = {characterType};