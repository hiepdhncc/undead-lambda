const characterType = "character-type"; 
const character = "character"; 

module.exports = {characterType, character};