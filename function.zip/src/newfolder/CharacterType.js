const dynamo = require('../config/dynamo')
const table = require('../constants/table');

async function saveCharacterType(requestBody){
  const params = {
    TableName: table.characterType,
    Item: requestBody
  };
  return await dynamo.put(params).promise().then(() => {
    const body = {
      Operation: 'SAVE',
      Message: 'SUCCESS',
      Item: requestBody
    };
    return buildResponse(200, body);
  }, (error) => {
    console.error('Do your custom error handling here. I am just gonna log it: ', error);
  });
}

module.exports = {saveCharacterType};