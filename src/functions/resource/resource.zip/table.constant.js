const userCharacter = "user_character"; 
const userResource = "user_resource"; 
const userReward = "user_reward";
const userWeapon = "user_weapon"; 

module.exports = {
  userCharacter, 
  userResource, 
  userReward, 
  userWeapon
};