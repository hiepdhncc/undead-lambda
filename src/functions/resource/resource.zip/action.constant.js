
exports.createUserResource = 'createUserResource';
exports.findUserResource = 'findUserResource';
exports.findAllUserResource = 'findAllUserResource';
exports.deleteUserResource = 'deleteUserResource';
exports.modifyUserResource = 'modifyUserResource';

exports.createUserReward = 'createUserReward';
exports.findUserReward = 'findUserReward';
exports.findAllUserReward = 'findAllUserReward';
exports.deleteUserReward = 'deleteUserReward';
exports.modifyUserReward = 'modifyUserReward';
exports.claimResource = 'claimResource';
