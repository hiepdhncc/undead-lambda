const characterType = "character-type"; 
const character = "character"; 
const userCharacter = "user-character"; 

module.exports = {
  characterType,
  character,
  userCharacter, 
};