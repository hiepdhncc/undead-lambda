exports.createCharacterType = 'createCharacterType';
exports.findCharacterType = 'findCharacterType';
exports.findAllCharacterType = 'findAllCharacterType';
exports.deleteCharacterType = 'deleteCharacterType';
exports.modifyCharacterType = 'modifyCharacterType';

exports.createCharacter = 'createCharacter';
exports.findCharacter = 'findCharacter';
exports.findAllCharacter = 'findAllCharacter';
exports.deleteCharacter = 'deleteCharacter';
exports.modifyCharacter = 'modifyCharacter';

exports.createUserCharacter = 'createUserCharacter';
exports.findUserCharacter = 'findUserCharacter';
exports.findAllUserCharacter = 'findAllUserCharacter';
exports.deleteUserCharacter = 'deleteUserCharacter';
exports.modifyUserCharacter = 'modifyUserCharacter';
