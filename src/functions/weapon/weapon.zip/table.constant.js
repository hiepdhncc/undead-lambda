const weaponType = "weapon-type"; 
const weapon = "weapon"; 
const ammo = "ammo"; 
const userWeapon = "user-weapon"; 
const weaponLevel = "weapon-level"; 

module.exports = {
  weapon,
  weaponLevel,
  weaponType,
  ammo,
  userWeapon
};