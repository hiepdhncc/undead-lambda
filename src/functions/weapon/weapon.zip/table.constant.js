const userWeapon = "user_weapon"; 
const userSkin = "user_skin"; 

module.exports = {
  userWeapon,
  userSkin,
};