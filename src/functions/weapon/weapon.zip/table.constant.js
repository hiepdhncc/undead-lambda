const userWeapon = "user-weapon"; 
const userSkin = "user-skin"; 

module.exports = {
  userWeapon,
  userSkin,
};