exports.createUserWeapon = 'createUserWeapon';
exports.findUserWeapon = 'findWeapon';
exports.findAllUserWeapon = 'findAllUserWeapon';
exports.deleteUserWeapon = 'deleteUserWeapon';
exports.modifyUsereapon = 'modifyUsereapon';

exports.getAllWeaponOfUser = 'getAllWeaponOfUser';
exports.getWeaponDetail = 'getWeaponDetail';
exports.purchaseSkin = 'purchaseSkin';
exports.purchaseWeapon = 'purchaseWeapon';
exports.upgradeWeapon = 'upgradeWeapon';